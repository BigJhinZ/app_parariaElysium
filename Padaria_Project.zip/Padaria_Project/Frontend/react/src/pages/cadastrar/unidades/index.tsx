import { UnityRegistrationTp } from "templates/unity/registration";

export default function UnityRegistrationPage() {
  return <UnityRegistrationTp />;
}
