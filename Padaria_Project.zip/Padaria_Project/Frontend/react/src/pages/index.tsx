import { UnityListTp } from "templates/unity/list";

export default function UnityListPage() {
  return <UnityListTp />;
}
