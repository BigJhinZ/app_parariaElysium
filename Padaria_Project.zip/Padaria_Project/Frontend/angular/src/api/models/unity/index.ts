export type Unity = {
  id?: Number;
  name: string;
};
